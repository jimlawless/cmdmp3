Please see the blog post at:

https://jimlawless.net/blog/posts/cmdmp3/


